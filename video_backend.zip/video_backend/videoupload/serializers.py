from rest_framework import serializers
from .models import *


class VideoUploadSerializer(serializers.ModelSerializer):
    subtitles = serializers.ListField(child=serializers.JSONField())

    class Meta:
        model = Video
        fields = ('title', 'video_file', 'subtitles')
