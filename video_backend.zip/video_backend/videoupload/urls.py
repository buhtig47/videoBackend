from django.urls import path
from .views import *

urlpatterns = [
    path('api/upload/', VideoUploadView.as_view(), name='video-upload'),
    path('api/media/<str:title>/', ProtectedMediaView.as_view(), name='protected-media'),
]
