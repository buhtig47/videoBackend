from django.db import models

class Subtitle(models.Model):
    text = models.CharField(max_length=200)
    timestamp = models.CharField(max_length=20)

class Video(models.Model):
    title = models.CharField(max_length=100)
    video_file = models.FileField(upload_to='videos/')
    subtitles = models.ManyToManyField(Subtitle, blank=True)
