from rest_framework.views import APIView
from rest_framework import status
from .models import *
from .serializers import *
from django.http import HttpResponse
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.parsers import JSONParser
import json


class VideoUploadView(APIView):
    def post(self, request, *args, **kwargs):
        serializer = VideoUploadSerializer(data=request.data)

        if serializer.is_valid():
            subtitles_data = request.POST.get('subtitles')
            subtitles_list = json.loads(subtitles_data)

            video = Video.objects.create(title=request.POST.get('title'), video_file=request.POST.get('video_file'))
            for subtitle_data in subtitles_list:
                text = subtitle_data['text']
                timestamp = subtitle_data['timestamp']
                subtitle = Subtitle.objects.create(text=text, timestamp=timestamp)
                video.subtitles.add(subtitle)  

            return Response(status=status.HTTP_201_CREATED)


class ProtectedMediaView(APIView):
    def get(self, request, title, *args, **kwargs):
        try:
            video = Video.objects.get(title=title)
            full_path = video.video_file.path

            with open(full_path, 'rb') as f:
                file_content = f.read()

            response = HttpResponse(file_content, content_type='application/octet-stream')
            response['Access-Control-Allow-Origin'] = '*' 
            return response
        except Video.DoesNotExist:
            return HttpResponse(status=status.HTTP_404_NOT_FOUND)
